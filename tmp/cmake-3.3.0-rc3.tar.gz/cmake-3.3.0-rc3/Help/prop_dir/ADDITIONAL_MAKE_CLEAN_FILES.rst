ADDITIONAL_MAKE_CLEAN_FILES
---------------------------

Additional files to clean during the make clean stage.

A list of files that will be cleaned as a part of the "make clean"
stage.
