RULE_LAUNCH_COMPILE
-------------------

Specify a launcher for compile rules.

See the global property of the same name for details.  This overrides
the global property for a directory.
